import React from 'react';
import ReactDOM from 'react-dom';
import {BrowserRouter as Router, Route, IndexRoute} from 'react-router-dom';
import App from './src/components/App.jsx';
import patientHome from './src/components/patient/patientHome.jsx';
import patientTerms from './src/components/patient/patientTerms.jsx';
import patientRegistrationComplete from './src/components/patient/patientRegistrationComplete.jsx';
import patientProfile1 from './src/components/patient/patientProfile1.jsx';
import patientProfile2 from './src/components/patient/patientProfile2.jsx';
import patientProfile3 from './src/components/patient/patientProfile3.jsx';
import patientProfile4 from './src/components/patient/patientProfile4.jsx';
import patientProfile5 from './src/components/patient/patientProfile5.jsx';
import patientProfileComplete from './src/components/patient/patientProfileComplete.jsx';
import about from './src/components/about.jsx';
import contact from './src/components/contact.jsx';


ReactDOM.render((
   /*<Router history={ReactRouter.hashHistory}>
      <Route path = "/" component = {App}>
         <IndexRoute component = {home} />
         <Route path = "home" component = {home} />
         <Route path = "about" component = {about} />
         <Route path = "contact" component = {contact} />
      </Route>
   </Router>*/
    <Router>
    <div>
      <Route path="/" component={App} />
      <Route exact path="/" component={patientHome} />
      <Route path = "/patientHome" component = {patientHome} />
      <Route path = "/patientTerms" component = {patientTerms} />
      <Route path = "/patientRegistrationComplete" component = {patientRegistrationComplete} />
      <Route path = "/patientProfile1" component = {patientProfile1} />
      <Route path = "/patientProfile2" component = {patientProfile2} />
      <Route path = "/patientProfile3" component = {patientProfile3} />
      <Route path = "/patientProfile4" component = {patientProfile4} />
      <Route path = "/patientProfile5" component = {patientProfile5} />
      <Route path = "/patientProfileComplete" component = {patientProfileComplete} />      
      <Route path="/about" component={about} />
      <Route path="/contact" component={contact} />
      </div>
    </Router>
	
), document.getElementById('app'))