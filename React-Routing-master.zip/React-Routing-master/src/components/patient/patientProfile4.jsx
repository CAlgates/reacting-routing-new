import React from 'react';
import ReactDOM from 'react-dom';
import createHistory from 'history/createBrowserHistory';
import {BrowserRouter as Router, Route, Link} from 'react-router-dom';


class patientProfile4 extends React.Component {
	constructor(props) {
		super(props);
		this.backpage = this.backpage.bind(this);
		this.skip = this.skip.bind(this);
		this.continue = this.continue.bind(this);
	}
	backpage(){
		console.log("clicked complete button");
		this.props.history.goBack();
	}
	skip(){
		console.log("clicked skip button");
		this.props.history.push('patientHome');
	}
	continue(){
		console.log("clicked continue button");
		let medname1=ReactDOM.findDOMNode(this.refs.medname1).value;
		let medname2=ReactDOM.findDOMNode(this.refs.medname2).value;
		let medname3=ReactDOM.findDOMNode(this.refs.medname3).value;
		let medname4=ReactDOM.findDOMNode(this.refs.medname4).value;
		console.log("medname1",medname1);
		console.log("medname2",medname2);
		console.log("medname3",medname3);
		console.log("medname4",medname4);
		this.props.history.push('patientProfile5');
	}
   	render() {
    	return (
        	<div>
    			<div className="leftContent">
	        		Select your conditions.
				</div>
				<div className="rightContent">
					progress bar
				</div>
				<div className="clear"></div>
				<div>
					<input type="text" name="search" value="search" />
					<div>
						<div className="SingleRow">
							Medication Name<br />
							<input type="text" ref="medname1" />
						</div>
						<div className="SingleRow">
							Medication Name<br />
							<input type="text" ref="medname2" />
						</div>
						<div className="SingleRow">
							Medication Name<br />
							<input type="text" ref="medname3" />
						</div>
						<div className="SingleRow">
							Medication Name<br />
							<input type="text" ref="medname4" />
						</div>
						<div className="clear"></div> 
					</div>
				</div>
	        	<div className="leftContent">
	        		<button type="button" onClick={this.backpage}> back
					</button>	
				</div>
				<div className="rightContent">
					<button type="button" onClick={this.skip}> skip
					</button>
					<button type="button" onClick={this.continue}> continue
					</button>
				</div>
				<div className="clear"></div>        		
        	</div>
      	)
   	}
}

export default patientProfile4;