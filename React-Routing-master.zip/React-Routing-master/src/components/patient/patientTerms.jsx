import React from 'react';
import ReactDOM from 'react-dom';
import createHistory from 'history/createBrowserHistory';
import {BrowserRouter as Router, Route, Link} from 'react-router-dom';

class PatientHome extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			"term1" : false,
			"term2" : false,
			"term3" : false,
			"term4" : false
		}
		this.decline = this.decline.bind(this);
		this.accept = this.accept.bind(this);
		this.handlecheck1 = this.handlecheck1.bind(this);
		this.handlecheck2 = this.handlecheck2.bind(this);
		this.handlecheck3 = this.handlecheck3.bind(this);
		this.handlecheck4 = this.handlecheck4.bind(this);
	}
	handlecheck1(e){
		this.state.term1 = e.target.checked;
	}
	handlecheck2(e){
		this.state.term2 = e.target.checked;
	}
	handlecheck3(e){
		this.state.term3 = e.target.checked;
	}
	handlecheck4(e){
		this.state.term4 = e.target.checked;
	}
	decline(){
		console.log("clicked decline button");
		this.props.history.push('patientHome');
	}
	accept(){
		console.log("clicked accept button");
		console.log("this.state.term1",this.state.term1);
		console.log("this.state.term1",this.state.term2);
		console.log("this.state.term1",this.state.term3);
		console.log("this.state.term1",this.state.term4);
		if(this.state.term1 && this.state.term2 && this.state.term3 && this.state.term4)
		this.props.history.push('patientRegistrationComplete');
		else
		console.log("please select all the conditions");
	}
   	render() {
    	return (
        	<div>
        		<p>Terms and conditions</p>
        		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
        		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
        		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
        		cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
        		proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
        		Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
        		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
        		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
        		cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
        		proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
        		Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
        		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
        		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
        		cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
        		proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
        		</p>
        		<label>
					<input id="checkboxinput" type="checkbox" name="remember" onChange={this.handlecheck1}/> Terms 1
				</label>
				<label>
					<input id="checkboxinput" type="checkbox" name="remember" onChange={this.handlecheck2}/> Terms 2
				</label>
				<label>
					<input id="checkboxinput" type="checkbox" name="remember" onChange={this.handlecheck3}/> Terms 3
				</label>
				<label>
					<input id="checkboxinput" type="checkbox" name="remember" onChange={this.handlecheck4}/> Terms 4
				</label>
				<button type="button" onClick={this.decline}> Decline
				</button>
				<button type="button" onClick={this.accept}> Accept
				</button>

        	</div>
      	)
   	}
}

export default PatientHome;