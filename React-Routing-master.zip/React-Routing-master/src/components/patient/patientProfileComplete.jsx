import React from 'react';
import ReactDOM from 'react-dom';
import createHistory from 'history/createBrowserHistory';
import {BrowserRouter as Router, Route, Link} from 'react-router-dom';


class patientProfileComplete extends React.Component {
	constructor(props) {
		super(props);
    this.state={
      samplejsondata:'json data click get started to view'
    }
		this.getstarted = this.getstarted.bind(this);
	}
  componentDidMount(){
    fetch('src/data/sampledata.json')
    .then(results => {
      results.json()
      .then(data=>
       this.setState({
                    samplejsondata: data.characters[0]
        }),
      
      );
    })
  }
	getstarted(){
		console.log("clicked getstarted button");
		this.props.history.push('patientProfileComplete');
	}
   	render() {
    	return (
        	<div>
    			<p>Your profile is complete.</p>
    			<p>Static content</p>
    			<p>Complete progress bar.</p>
          <p>{this.state.samplejsondata}</p>
    			<p>Now that ur profile is complete. Try to learn and explore more.</p>
    			<button type="button" onClick={this.getstarted}> Get Started
				</button>

        	</div>
      	)
   	}
}

export default patientProfileComplete;