import React from 'react';
import ReactDOM from 'react-dom';
import createHistory from 'history/createBrowserHistory';
import {BrowserRouter as Router, Route, Link} from 'react-router-dom';


class patientProfile1 extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			selected:''
		};
		this.backpage = this.backpage.bind(this);
		this.skip = this.skip.bind(this);
		this.continue = this.continue.bind(this);
	}
	backpage(){
		console.log("clicked complete button");
		this.props.history.goBack();
	}
	skip(){
		console.log("clicked skip button");
		this.props.history.push('patientHome');
	}
	continue(){
		let dob=ReactDOM.findDOMNode(this.refs.dob).value;
		let height=ReactDOM.findDOMNode(this.refs.height).value;
		let weight=ReactDOM.findDOMNode(this.refs.weight).value;
		console.log("dob",dob);
		console.log("height",height);
		console.log("weight",weight);
		console.log("clicked continue button");
		console.log("selected",this.state.selected);
		this.props.history.push('patientProfile2');
	}
   	render() {
    	return (
        	<div>
	        	<div className="leftContent">
	        		<label>
						<input id="checkboxinput" type="radio" name="male"  value='male'
          					checked={this.state.selected === 'male'} onChange={(e) => this.setState({ selected: e.target.value })} /> Male
					</label>
					<label>
						<input id="checkboxinput" type="radio" name="female"  value='female'
          					checked={this.state.selected === 'female'} onChange={(e) => this.setState({ selected: e.target.value })} /> Female
					</label>
					<label>
						<input id="checkboxinput" type="radio" name="transgender"  value='transgender'
          					checked={this.state.selected === 'transgender'} onChange={(e) => this.setState({ selected: e.target.value })}/> Transgender
					</label>
					<label>
						<input id="checkboxinput" type="radio" name="nodisclose"  value='nodisclose'
          					checked={this.state.selected === 'nodisclose'} onChange={(e) => this.setState({ selected: e.target.value })}/> I prefer not to disclose
					</label>	
					<button type="button" onClick={this.backpage}> back
					</button>
				</div>
				<div className="rightContent">
					<p>Use ur point</p>
					<p>Static content</p>
					Date of birth:<br />
					<input type="date" ref="dob" />
					<br />
					Height:<br />
					<input type="text" ref="height" />
					<br />
					Weight:<br />
					<input type="text" ref="weight" />
					<br />
					
					<button type="button" onClick={this.skip}> skip
					</button>
					<button type="button" onClick={this.continue}> continue
					</button>
				</div>
				<div className="clear"></div>        		
        	</div>
      	)
   	}
}

export default patientProfile1;