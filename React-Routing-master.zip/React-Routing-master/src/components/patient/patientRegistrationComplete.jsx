import React from 'react';
import ReactDOM from 'react-dom';
import createHistory from 'history/createBrowserHistory';
import {BrowserRouter as Router, Route, Link} from 'react-router-dom';


class patientRegistrationComplete extends React.Component {
	constructor(props) {
		super(props);
		this.complete = this.complete.bind(this);
		this.skipnstart = this.skipnstart.bind(this);
	}
	complete(){
		console.log("clicked complete button");
		this.props.history.push('patientProfile1');
	}
	skipnstart(){
		console.log("clicked skipnstart button");
		this.props.history.push('patientHome');
	}
   	render() {
    	return (
        	<div>
	        	<div className="leftContent">
	        		<h1>Congratulations!</h1>
	        		<p> Static content</p>	
				</div>
				<div className="rightContent">
					<p>Use ur point</p>
					<p>Static content</p>
					<button type="button" onClick={this.complete}> Complete Profile
					</button>
					<button type="button" onClick={this.skipnstart}> Skip and get started
					</button>
				</div>
				<div className="clear"></div>        		
        	</div>
      	)
   	}
}

export default patientRegistrationComplete;