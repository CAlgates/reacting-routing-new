import React from 'react';
import ReactDOM from 'react-dom';
import createHistory from 'history/createBrowserHistory';
import {BrowserRouter as Router, Route, Link} from 'react-router-dom';


class patientProfile5 extends React.Component {
	constructor(props) {
		super(props);
		this.state= {
			selected: ''
		}
		this.backpage = this.backpage.bind(this);
		this.skip = this.skip.bind(this);
		this.continue = this.continue.bind(this);
	}
	backpage(){
		console.log("clicked complete button");
		this.props.history.goBack();
	}
	skip(){
		console.log("clicked skip button");
		this.props.history.push('patientHome');
	}
	continue(){
		console.log("clicked continue button");
		let doctorcode=ReactDOM.findDOMNode(this.refs.doctorcode).value;
		console.log("doctorcode",doctorcode);
		console.log("this.state.selected",this.state.selected);
		this.props.history.push('patientProfileComplete');
	}
   	render() {
    	return (
        	<div>
    			<div className="leftContent">
	        		Connect with doctor or pharmacist.
				</div>
				<div className="rightContent">
					progress bar
				</div>
				<div className="clear"></div>
				<div>
					<div className="leftContent">
						<p>You can connect with ur doctor or pharmacist through a:care.Use the code given to you to connect with your doctor.</p>
						Enter your Doctor/Pharmacist code:<br />
						<input type="text" ref="doctorcode" />
		        		<button type="button" onClick={this.search}> search
						</button>	
					</div>
					<div className="rightContent">
						<p>Your Doctor</p>
						<p>Doctor card</p>
					</div>
				</div>
				<div className="clear"></div>
				<div>
					<div className="leftContent">
						<p>Dont have a code? skip this step and search for new doctor/HCP.</p>
					</div>
					<div className="rightContent">
						<label>
						<input id="checkboxinput" type="checkbox" name="acceptance"  value='acceptance'
          					checked={this.state.selected === 'acceptance'} onChange={(e) => this.setState({ selected: e.target.value })} /> I am acknowledging that i will share my details with this doctor/HCP.
					</label>
					</div>
				</div>
				<div className="clear"></div>
	        	<div className="leftContent">
	        		<button type="button" onClick={this.backpage}> back
					</button>	
				</div>
				<div className="rightContent">
					<button type="button" onClick={this.skip}> skip
					</button>
					<button type="button" onClick={this.continue}> continue
					</button>
				</div>
				<div className="clear"></div>        		
        	</div>
      	)
   	}
}

export default patientProfile5;