import React from 'react';
import ReactDOM from 'react-dom';
import createHistory from 'history/createBrowserHistory';
import {BrowserRouter as Router, Route, Link} from 'react-router-dom';


class PatientHome extends React.Component {
	constructor(props) {
		super(props);
		this.state={
			privacyCheckbox : false
		}
		this.submit = this.submit.bind(this);
		this.handlecheck = this.handlecheck.bind(this);
	}
	handlecheck(e){
		this.state.privacyCheckbox = e.target.checked;
	}
	submit(){
		console.log("clicked submit button");
		let firstName=ReactDOM.findDOMNode(this.refs.firstName).value;
		let lastName=ReactDOM.findDOMNode(this.refs.lastName).value;
		let email=ReactDOM.findDOMNode(this.refs.email).value;
		let password=ReactDOM.findDOMNode(this.refs.password).value;
		let reenterpassword=ReactDOM.findDOMNode(this.refs.reenterpassword).value;
		if(password!=reenterpassword && password!=null || reenterpassword!=null)
		{
			console.log("please confirm both the password are same");
		}
		else
		{	
			this.props.history.push('patientTerms');
		}
		console.log("firstName",firstName);
		console.log("lastName",lastName);
		console.log("email",email);
		console.log("password",password);
		console.log("reenterpassword",reenterpassword);
		console.log("this.state.privacyCheckbox",this.state.privacyCheckbox);		
		
	}
   	render() {
    	return (
        	<div>
	        	<div className="leftContent">
		         	<div id="abbottLogo">Abbott logo</div>
		         	<p>Register</p>
		         	<p>Are you a patient,Doctor or Pharmacist?</p>
		            <div className="navigation">
					    <ul className="navigation-content">
					      	<li><Link to="patienthome">I'm a Patient</Link></li>
					       	<li><Link to="about">I'm a Doctor</Link></li>
					       	<li><Link to="contact">I'm a Pharmacist</Link></li>
					    </ul>			   
					</div>	
					<div className="clear"></div>
					<div>
					<a href="https://www.facebook.com">Connect with facebook</a>
	        		<form noValidate>
	        			<fieldset>
	  						<legend>Or enter your info here:</legend>  						
							<input type="text" placeholder="First Name" ref="firstName" required />						
							<input type="text" placeholder="Last Name" ref="lastName" required />
							<input type="text" placeholder="Email" ref="email" required />
							<input type="password" placeholder="Password" ref="password" required />
							<input type="password" placeholder="Re-enter Password" ref="reenterpassword" required />
							<label>
								<input id="checkboxinput" type="checkbox" name="remember" onChange={this.handlecheck} /> Privacy Policy
							</label>
							<button type="button" onClick={this.submit}> Create Account
							</button>

							<a href="https://www.facebook.com">Already signed up? Log in Here</a>
						</fieldset>
	        		</form>
	        		</div> 				
				</div>
				<div className="rightContent">
					<p>Static content</p>
				</div>
				<div className="clear"></div>        		
        	</div>
      	)
   	}
}

export default PatientHome;