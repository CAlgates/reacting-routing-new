import React from 'react';
import ReactDOM from 'react-dom';
import createHistory from 'history/createBrowserHistory';
import {BrowserRouter as Router, Route, Link} from 'react-router-dom';


class patientProfile3 extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			"activity1" : false,
			"activity2" : false,
			"activity3" : false,
			"activity4" : false,
			"selectValue1": '',
			"selectValue2": ''
		}
		this.handleactivity1 = this.handleactivity1.bind(this);
		this.handleactivity2 = this.handleactivity2.bind(this);
		this.handleactivity3 = this.handleactivity3.bind(this);
		this.handleactivity4 = this.handleactivity4.bind(this);
		this.handleChange1 = this.handleChange1.bind(this);
		this.handleChange2 = this.handleChange2.bind(this);
		this.backpage = this.backpage.bind(this);
		this.skip = this.skip.bind(this);
		this.continue = this.continue.bind(this);
	}
	handleactivity1(e){
		this.state.activity1 = e.target.checked;
	}
	handleactivity2(e){
		this.state.activity2 = e.target.checked;
	}
	handleactivity3(e){
		this.state.activity3 = e.target.checked;
	}
	handleactivity4(e){
		this.state.activity4 = e.target.checked;
	}
	backpage(){
		console.log("clicked complete button");
		this.props.history.goBack();
	}
	handleChange1(e){
    	this.setState({selectValue1:e.target.value});
	}
	handleChange2(e){
		this.setState({selectValue2:e.target.value});
	}
	skip(){
		console.log("clicked skip button");
		this.props.history.push('patientHome');
	}
	continue(){
		console.log("clicked continue button");
		console.log("this.state.activity1",this.state.activity1);
		console.log("this.state.activity2",this.state.activity2);
		console.log("this.state.activity3",this.state.activity3);
		console.log("this.state.activity4",this.state.activity4);
		console.log("this.state.selectValue1",this.state.selectValue1);
		console.log("this.state.selectValue2",this.state.selectValue2);
		this.props.history.push('patientProfile4');
	}
   	render() {
    	return (
        	<div>
    			<div className="leftContent">
	        		Select your conditions.
				</div>
				<div className="rightContent">
					progress bar
				</div>
				<div className="clear"></div>
				<div>
					<div className="leftContent">
						<label>
							<input id="checkboxinput" type="checkbox" value='activity1' name="activity" onChange={this.handleactivity1} /> swimming
						</label>
						<label>
							<input id="checkboxinput" type="checkbox" value='activity2' name="activity" onChange={this.handleactivity2} /> walking
						</label>
						<label>
							<input id="checkboxinput" type="checkbox" value='activity3' name="activity" onChange={this.handleactivity3} /> gym
						</label>
						<label>
							<input id="checkboxinput" type="checkbox" value='activity4' name="activity" onChange={this.handleactivity4} /> yoga
						</label>
					</div>
					<div className="rightContent">
						How often do you excercise?
						<select onChange={this.handleChange1} >
						  <option value="Daily">Daily</option>
						  <option value="Weekly">Weekly</option>
						  <option value="Monthly">Monthly</option>
						  <option value="Never">Never</option>
						</select>
						<br />
						How often do you smoke
						<select onChange={this.handleChange2} >
						  <option value="Never">Never</option>
						  <option value="Once">Once in a week</option>
						  <option value="Everyday">Everyday</option>
						</select>
					</div>
				</div>
				<div className="clear"></div>
	        	<div className="leftContent">
	        		<button type="button" onClick={this.backpage}> back
					</button>	
				</div>
				<div className="rightContent">
					<button type="button" onClick={this.skip}> skip
					</button>
					<button type="button" onClick={this.continue}> continue
					</button>
				</div>
				<div className="clear"></div>        		
        	</div>
      	)
   	}
}

export default patientProfile3;