import React from 'react';
import ReactDOM from 'react-dom';
import createHistory from 'history/createBrowserHistory';
import {BrowserRouter as Router, Route, Link} from 'react-router-dom';


class patientProfile2 extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			"conditions1" : false,
			"conditions2" : false,
			"conditions3" : false,
			"conditions4" : false
		}
		this.handleconditions1 = this.handleconditions1.bind(this);
		this.handleconditions2 = this.handleconditions2.bind(this);
		this.handleconditions3 = this.handleconditions3.bind(this);
		this.handleconditions4 = this.handleconditions4.bind(this);
		this.backpage = this.backpage.bind(this);
		this.skip = this.skip.bind(this);
		this.continue = this.continue.bind(this);
	}
	handleconditions1(e){
		this.state.conditions1 = e.target.checked;
	}
	handleconditions2(e){
		this.state.conditions2 = e.target.checked;
	}
	handleconditions3(e){
		this.state.conditions3 = e.target.checked;
	}
	handleconditions4(e){
		this.state.conditions4 = e.target.checked;
	}
	backpage(){
		console.log("clicked complete button");
		this.props.history.goBack();
	}
	skip(){
		console.log("clicked skip button");
		this.props.history.push('patientHome');
	}
	continue(){
		let datedata=ReactDOM.findDOMNode(this.refs.datedata).value;
		console.log("clicked continue button");
		console.log("datedata",datedata);
		console.log("this.state.conditions1",this.state.conditions1);
		console.log("this.state.conditions2",this.state.conditions2);
		console.log("this.state.conditions3",this.state.conditions3);
		console.log("this.state.conditions4",this.state.conditions4);
		this.props.history.push('patientProfile3');
	}
   	render() {
    	return (
        	<div>
    			<div className="leftContent">
	        		Select your conditions.
				</div>
				<div className="rightContent">
					progress bar
				</div>
				<div className="clear"></div>
				<div>
					<input type="date" name="datedata" ref="datedata" />
					<label>
						<input id="checkboxinput" type="checkbox" name="conditions1" onChange={this.handleconditions1}/> conditions
					</label>
					<label>
						<input id="checkboxinput" type="checkbox" name="conditions2" onChange={this.handleconditions2}/> conditions
					</label>
					<label>
						<input id="checkboxinput" type="checkbox" name="conditions3" onChange={this.handleconditions3}/> conditions
					</label>
					<label>
						<input id="checkboxinput" type="checkbox" name="conditions4" onChange={this.handleconditions4}/> conditions
					</label>
				</div>
	        	<div className="leftContent">
	        		<button type="button" onClick={this.backpage}> back
					</button>	
				</div>
				<div className="rightContent">
					<button type="button" onClick={this.skip}> skip
					</button>
					<button type="button" onClick={this.continue}> continue
					</button>
				</div>
				<div className="clear"></div>        		
        	</div>
      	)
   	}
}

export default patientProfile2;