import React from 'react';
import ReactDOM from 'react-dom';
import {BrowserRouter as Router, Route, Link} from 'react-router-dom';

class App extends React.Component {
   render() {
      return (
         <div>
         	<div className="example-content">	    
				    {this.props.children}
				</div>
         </div>
      );
   }
}

export default App;