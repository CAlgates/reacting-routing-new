import React from 'react';
import ReactDOM from 'react-dom';
import {BrowserRouter as Router, Route, Link} from 'react-router-dom';


class Contact extends React.Component {
   	render() {
    	return (
        	<div>
	        	<div className="leftContent">
		         	<div id="abbottLogo">Abbott logo</div>
		         	<p>Register</p>
		         	<p>Are you a patient,Doctor or Pharmacist?</p>
		            <div className="navigation">
					    <ul className="navigation-content">
					      	<li><Link to="patienthome">I'm a Patient</Link></li>
					       	<li><Link to="about">I'm a Doctor</Link></li>
					       	<li><Link to="contact">I'm a Pharmacist</Link></li>
					    </ul>			   
					</div>
					<div className="clear"></div>
					<div>
	        		<a href="https://www.facebook.com">Connect with facebook</a>
	        		<form>
	        			<fieldset>
	  						<legend>Or enter your info here:</legend>  						
							<input type="text" placeholder="First Name" name="email" required />						
							<input type="text" placeholder="Last Name" name="email" required />
							<input type="text" placeholder="Email" name="email" required />
							<input type="password" placeholder="Password" name="psw" required />
							<input type="password" placeholder="Re-enter Password" name="psw-repeat" required />
							<p>You might be a doctor/Pharmacist</p>
							<input type="password" placeholder="abbott access code" name="psw-repeat" required />
							<a href="https://www.facebook.com">Dont have an access code? Click Here</a>
							<label>
								<input id="checkboxinput" type="checkbox" name="remember" onChange="" /> Privacy Policy
							</label>
							<button> Create Account
							</button>

							<a href="https://www.facebook.com">Already signed up? Log in Here</a>
						</fieldset>
	        		</form> 
	        		</div>
	        	</div>
				<div className="rightContent">
					<p>Static content</p>
				</div>
				<div className="clear"></div>        		
        	</div>
      	)
   	}
}

export default Contact;